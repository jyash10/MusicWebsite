<?php
     header("location: login1.php");
?>