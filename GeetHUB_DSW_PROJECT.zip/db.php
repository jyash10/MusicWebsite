<?php
$con=mysqli_connect("localhost:3307","root","","songdata");
if(!$con)
{
    die("connection failed");
}

?>